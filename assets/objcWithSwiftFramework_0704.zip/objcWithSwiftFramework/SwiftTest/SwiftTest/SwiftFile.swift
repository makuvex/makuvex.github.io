//
//  SwiftFile.swift
//  SwiftTest
//
//  Created by 정지원 on 2022/04/04.
//

import Foundation
import UIKit

public class SwiftFile: NSObject {
    
    @objc public var string: String? = "Swift test"
    
    @objc public func printString() {
        print("Test Swift is Working")
    }
}
