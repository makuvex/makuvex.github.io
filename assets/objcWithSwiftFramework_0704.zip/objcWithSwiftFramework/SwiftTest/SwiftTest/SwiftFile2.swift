//
//  SwiftFile2.swift
//  SwiftTest
//
//  Created by 정지원 on 2022/04/04.
//

import Foundation
import UIKit
import ObjcTest

public class SwiftFile2: NSObject {
    
    @objc public var title: String? = "SwiftFile2 title"
    
//    @objc public func print() -> String {
//        return "print SwiftFile2"
//    }
    
    @objc public func alert(viewController: UIViewController) {
        let alert = UIAlertController(title: "이거슨 swift alert", message: "이거슨 swift alert message", preferredStyle: .alert)
        let action = UIAlertAction(title: "확인", style: .default)
        alert.addAction(action)
        
        viewController.present(alert, animated: true, completion: nil)
        
        let objc = ObjcTestClass()
        print("test1 \(objc.string)")
        objc.string = "aaa"
        print("test2 \(objc.string)")
    }
}
