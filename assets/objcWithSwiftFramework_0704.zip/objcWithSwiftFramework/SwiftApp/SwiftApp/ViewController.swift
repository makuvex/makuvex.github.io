//
//  ViewController.swift
//  SwiftApp
//
//  Created by makuvex7 on 2022/07/04.
//

import UIKit
import SwiftTest

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let a = SwiftFile2()
        a.alert(viewController: self)
    }


}

