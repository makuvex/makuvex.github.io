//
//  AppDelegate.h
//  objcWithSwiftFramework
//
//  Created by 정지원 on 2022/04/04.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

