//
//  ViewController.m
//  objcWithSwiftFramework
//
//  Created by 정지원 on 2022/04/04.
//

#import "ViewController.h"
#import <SwiftTest/SwiftTest-Swift.h>
//#import <ObjcTest/ObjcTestClass.h>
//#import <ObjcWithWrappingSwift/WrappingSwift.h>

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    // Do any additional setup after loading the view.
    
//    ObjcTestClass *test = [[ObjcTestClass alloc] init];
//    NSLog(@"log %@", test.string);
//
////    SwiftFile *swift = [[SwiftFile alloc] init];
////    NSLog(@"log %@", swift.string);
////
//
//    WrappingSwift *wrapping = [[WrappingSwift alloc] init];
//    NSLog(@"log %@", [wrapping getStringText]);
//    NSLog(@"log %@", [wrapping getStringSwiftText]);
}

- (IBAction)clickedButton:(id)sender {
//    WrappingSwift *wrapping = [[WrappingSwift alloc] init];
//    [wrapping alert:self];
    
    SwiftFile2 *swiftFile2 = [[SwiftFile2 alloc] init];
    [swiftFile2 alertWithViewController:self];
    
}

@end
