//
//  WrappingSwift.m
//  ObjcWithWrappingSwift
//
//  Created by 정지원 on 2022/04/04.
//

#import "WrappingSwift.h"
#import <SwiftTest/SwiftTest-Swift.h>

@implementation WrappingSwift

- (instancetype)init {
    self = [super init];
    if (self) {
        self.string = @"WrappingSwift test";
    }
    return self;
}

-(NSString *)getStringText {
    return self.string;
}

-(NSString *)getStringSwiftText {
    SwiftFile *swift = [[SwiftFile alloc] init];
    
    [swift printString];
    return [NSString stringWithFormat:@"%@, %@", @"objc wrapping", swift.string];
}

- (void)alert:(UIViewController *)viewController {
    SwiftFile2 *swift2 = [[SwiftFile2 alloc] init];
    
    [swift2 alertWithViewController:viewController];
}

@end
