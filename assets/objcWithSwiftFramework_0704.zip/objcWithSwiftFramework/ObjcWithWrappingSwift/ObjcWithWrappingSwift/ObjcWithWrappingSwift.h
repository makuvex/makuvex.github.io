//
//  ObjcWithWrappingSwift.h
//  ObjcWithWrappingSwift
//
//  Created by 정지원 on 2022/04/04.
//

#import <Foundation/Foundation.h>
#import "WrappingSwift.h"

//! Project version number for ObjcWithWrappingSwift.
FOUNDATION_EXPORT double ObjcWithWrappingSwiftVersionNumber;

//! Project version string for ObjcWithWrappingSwift.
FOUNDATION_EXPORT const unsigned char ObjcWithWrappingSwiftVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ObjcWithWrappingSwift/PublicHeader.h>


