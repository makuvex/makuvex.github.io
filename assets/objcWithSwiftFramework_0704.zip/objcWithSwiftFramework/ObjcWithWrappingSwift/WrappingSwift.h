//
//  WrappingSwift.h
//  ObjcWithWrappingSwift
//
//  Created by 정지원 on 2022/04/04.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface WrappingSwift : NSObject

@property(nonatomic, strong) NSString *string;

-(NSString *)getStringText;
-(NSString *)getStringSwiftText;
-(void)alert:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
