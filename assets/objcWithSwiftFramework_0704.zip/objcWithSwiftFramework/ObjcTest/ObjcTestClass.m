//
//  ObjcTestClass.m
//  ObjcTest
//
//  Created by 정지원 on 2022/04/04.
//

#import "ObjcTestClass.h"
#import "ObjcTestClass_internal.h"

@implementation ObjcTestClass

- (instancetype)init {
    self = [super init];
    if (self) {
        _string = @"Objc test";
        _string2 = @"asdasdasasdlaksdas";
    }
    return self;
}

@end
