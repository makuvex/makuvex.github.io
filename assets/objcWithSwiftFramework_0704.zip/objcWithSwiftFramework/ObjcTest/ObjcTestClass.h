//
//  ObjcTestClass.h
//  ObjcTest
//
//  Created by 정지원 on 2022/04/04.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface ObjcTestClass : NSObject

@property(nonatomic, strong, readonly) NSString *string;
@property(nonatomic, strong, readonly) NSString *string2;

@end

NS_ASSUME_NONNULL_END
