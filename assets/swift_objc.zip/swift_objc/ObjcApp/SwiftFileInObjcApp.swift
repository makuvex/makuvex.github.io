//
//  SwiftFileInObjcApp.swift
//  ObjcApp
//
//  Created by makuvex7 on 2022/07/11.
//

import Foundation

@objcMembers public class SwiftFileInObjcApp: NSObject {
    public let desc: String = "SwiftFileInObjcApp"
    
    public func whoAmI() {
        
  //      let objc = ObjcFile()
        print("SwiftFileInObjcApp in whoAmI")
//        print("whoAmI : \(objc.desc)")
    }
}
