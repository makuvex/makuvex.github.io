//
//  SwiftFileInObjcAppExtension.swift
//  ObjcAppContentExtension
//
//  Created by makuvex7 on 2022/07/11.
//

import Foundation

@objcMembers public class SwiftFileInObjcAppExtension: NSObject {
    public let desc: String = "SwiftFileInObjcAppExtension"
    
    public func whoAmI() {
        print("SwiftFileInObjcAppExtension in whoAmI")
    }
}
