//
//  ShareViewController.h
//  ObjcAppShareExtension
//
//  Created by makuvex7 on 2022/07/11.
//

#import <UIKit/UIKit.h>
#import <Social/Social.h>

@interface ShareViewController : SLComposeServiceViewController

@end
