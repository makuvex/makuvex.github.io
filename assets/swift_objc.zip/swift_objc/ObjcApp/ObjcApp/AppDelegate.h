//
//  AppDelegate.h
//  ObjcApp
//
//  Created by makuvex7 on 2022/07/06.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

