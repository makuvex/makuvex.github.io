//
//  ViewController.h
//  ObjcApp
//
//  Created by makuvex7 on 2022/07/06.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

