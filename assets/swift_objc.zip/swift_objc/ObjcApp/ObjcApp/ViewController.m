//
//  ViewController.m
//  ObjcApp
//
//  Created by makuvex7 on 2022/07/06.
//

#import "ViewController.h"
//#import <ObjcFramework/ObjcFile.h>
#import <SwiftFramework/SwiftFramework-Swift.h>
#import "ObjcApp-Swift.h"


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
//    ObjcFile *objc = [[ObjcFile alloc] init];
    
//    SwiftFile *swift = [[SwiftFile alloc] init];
//    [swift whoAmI];
    
    SwiftFileInObjcApp *s = [[SwiftFileInObjcApp alloc] init];
    [s whoAmI];
}


@end
