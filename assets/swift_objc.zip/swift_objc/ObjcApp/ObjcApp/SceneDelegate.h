//
//  SceneDelegate.h
//  ObjcApp
//
//  Created by makuvex7 on 2022/07/06.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

