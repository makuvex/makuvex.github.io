//
//  ViewController.swift
//  SwiftApp
//
//  Created by makuvex7 on 2022/07/06.
//

import UIKit
//import SwiftFramework


class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
//        let a = SwiftFile()
//        a.whoAmI()
        
        let objc = ObjcFile()
        print(objc.desc)
    }
}

