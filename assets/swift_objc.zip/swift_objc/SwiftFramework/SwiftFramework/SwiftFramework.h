//
//  SwiftFramework.h
//  SwiftFramework
//
//  Created by makuvex7 on 2022/07/06.
//

#import <Foundation/Foundation.h>

//! Project version number for SwiftFramework.
FOUNDATION_EXPORT double SwiftFrameworkVersionNumber;

//! Project version string for SwiftFramework.
FOUNDATION_EXPORT const unsigned char SwiftFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SwiftFramework/PublicHeader.h>


