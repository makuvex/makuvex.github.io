//
//  SwiftFile.swift
//  SwiftFramework
//
//  Created by makuvex7 on 2022/07/06.
//

import Foundation
//import ObjcFramework

@objcMembers public class SwiftFile: NSObject {
    public let desc: String = "SwiftFile"
    
    public func whoAmI() {
        
  //      let objc = ObjcFile()
        print("@@@ SwiftFile in whoAmI")
//        print("whoAmI : \(objc.desc)")
    }
}
