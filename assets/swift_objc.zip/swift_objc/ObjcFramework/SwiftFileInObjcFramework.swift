//
//  SwiftFileInObjcFramework.swift
//  ObjcFramework
//
//  Created by makuvex7 on 2022/07/07.
//

import Foundation


@objcMembers public class SwiftFileInObjcFramework: NSObject {
    public let desc = "SwiftFileInObjcFramework"
    
    public func whoAmI() {
        print("whoAmI : SwiftFileInObjcFramework")
    }
}
