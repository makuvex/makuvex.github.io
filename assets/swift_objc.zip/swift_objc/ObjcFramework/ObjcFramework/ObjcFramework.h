//
//  ObjcFramework.h
//  ObjcFramework
//
//  Created by makuvex7 on 2022/07/06.
//

#import <Foundation/Foundation.h>

//! Project version number for ObjcFramework.
FOUNDATION_EXPORT double ObjcFrameworkVersionNumber;

//! Project version string for ObjcFramework.
FOUNDATION_EXPORT const unsigned char ObjcFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ObjcFramework/PublicHeader.h>


