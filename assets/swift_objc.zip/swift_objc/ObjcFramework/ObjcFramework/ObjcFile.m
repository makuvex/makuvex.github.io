//
//  ObjcFile.m
//  ObjcFramework
//
//  Created by makuvex7 on 2022/07/06.
//

#import "ObjcFile.h"
#import <ObjcFramework/ObjcFramework-Swift.h>

@implementation ObjcFile

- (instancetype)init {
    self = [super init];
    if (self) {
        _desc = @"ObjcFile";
    }
    
    SwiftFileInObjcFramework *s = [[SwiftFileInObjcFramework alloc] init];
    [s whoAmI];
    
    return self;
}

@end
